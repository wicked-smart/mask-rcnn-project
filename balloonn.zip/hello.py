

print("hello world")


